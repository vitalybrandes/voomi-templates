# NEON DANCE — Beat Drop v0.1.0

Prototype template package. 1 user VIDEO input, 10 seconds, 720x1280, 30 FPS export target.

## What is real
- Single PNG preview with no playback UI.
- Four original transparent overlay PNGs.
- Real decodable H264 moving placeholder video (3 seconds, repeated/trimmed by renderer to 10 seconds; the video is an illustrative dancer, not a photoreal recording).
- Original synthesized demo rhythm WAV (not professional music).
- JSON timeline with four scenes referencing the same media slot.

## Limitations
- Actual Flutter renderer compatibility not tested. Scene/layer contract is proposed and must be adapted to app code.
- Preview PNG is concept art from the same visual elements but NOT an actual export.
- User video must be >=10 seconds for this prototype; video placeholder itself is 3 seconds and needs loop behavior in the renderer.
- No real beat detection, audio sync, or professional music license.
- No claim of production readiness.
