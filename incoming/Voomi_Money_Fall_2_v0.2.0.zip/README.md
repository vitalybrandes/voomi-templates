Money Fall 2 v0.2.0 — corrected preview

The preview is a composite of the bundled sample photo and frame 1.75s from the bundled falling_coins.mp4. Black video background was removed using luma-key compositing (threshold ~0.09, softness ~0.16), not screen blending.

Voomi renderer MUST implement luma-key video compositing. If not, this is an integration prototype only and will show a black background. Sample photo is a temporary inherited placeholder and has decorative elements; replace with a clean licensed photo before production. Video redistribution rights unverified.
