# Voomi BFF Sunset Besties v0.4.0

Media-first integration prototype: 1 replaceable image/video, 8s, 720x1280.

Every sticker, frame and text graphic was authored as its own transparent PNG. No graphics were cropped from preview sheets. Polaroid center windows have alpha=0. Preview was assembled from the included assets.

Important: assets are clean original vector-style graphics, not AI-generated professional illustrations. The bundled placeholder is inherited from the old prototype and still contains some baked-in decorations; replace before production. Flutter renderer JSON compatibility is unverified. No music bundled.

The optional glow effects are transparent overlays. No full background is packaged.


## v0.5.0 warning
This package reuses v0.4.0 artwork. It is NOT a reproduction of the approved glossy Canva-style concept. Only package validation and preview compression were added. Do not publish as a production template.
