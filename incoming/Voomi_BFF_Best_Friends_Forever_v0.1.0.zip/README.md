# BFF — Best Friends Forever (v0.1.0)

One-photo, eight-second Voomi prototype.

- `preview/preview.png` is a static **concept poster**, not renderer output.
- `placeholders/friends_sample.jpg` is cropped from generated artwork; it contains some baked-in decoration and must be replaced with clean licensed photography before production.
- All effect stickers and title are separate transparent PNGs under `assets/images/`.
- JSON scene timing and effects are proposed and **not verified** against the actual Voomi Flutter renderer.
- No music is bundled; audio is intentionally absent rather than falsely represented as licensed professional music.
- Full runtime render and preview parity are not verified. Do not publish as production-ready.
