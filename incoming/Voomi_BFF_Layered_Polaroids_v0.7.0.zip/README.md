# Voomi BFF Layered Polaroids v0.7.0

One user image/video slot, reused as full-screen base and inside two Polaroid windows. Transparent Polaroid frame PNGs and stickers overlay the media. The media inside the frames is clipped; the two frames are NOT empty. No subject extraction or background removal.

The preview is a static sample assembled from actual packaged graphics and the same placeholder. Polaroid frame and media group rotations in template.json require group-transform support. The existing sticker artwork is still from the earlier simplified prototype and is NOT the glossy AI concept art; visual approval remains pending. Renderer compatibility is untested.
