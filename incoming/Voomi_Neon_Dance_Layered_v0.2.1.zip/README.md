Neon Dance — Layered v0.2.0

One replaceable video slot with transparent PNG sticker layers. PNG preview is composed from the actual packaged layers over the included demo frame.

LIMITATIONS: Sticker graphics are original vector-rendered neon designs, NOT individually AI-generated art. The separately AI-generated poster is art direction only and is NOT a renderer-accurate preview. JSON scene/rect/animation contract is proposed and not validated with the Voomi Flutter renderer. Demo audio and video are synthetic prototype materials. No background removal.
